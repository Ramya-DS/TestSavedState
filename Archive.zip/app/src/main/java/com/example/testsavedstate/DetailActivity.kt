package com.example.testsavedstate

import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        if(resources.configuration.orientation==Configuration.ORIENTATION_LANDSCAPE)
        {
            finish()
            return
        }

        else{
            val bundle = intent.extras
            val file=bundle?.let {
                Folder(
                    it.getString("name")!!,
                    it.getString("type")!!,
                    it.getInt("typeImage"),
                    it.getLong("size"),
                    it.getString("date")!!,
                    it.getString("path")!!
                )
            }

            supportFragmentManager.beginTransaction().replace(R.id.detailContainer,SingleFile(file!!)).commit()
        }
        }


}
