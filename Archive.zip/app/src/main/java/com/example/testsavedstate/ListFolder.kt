package com.example.testsavedstate


import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.FragmentTransaction.TRANSIT_FRAGMENT_FADE
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat

/**
 * A simple [Fragment] subclass.
 */
class ListFolder(var path: File) : Fragment(), OnViewHolderClickListener {

    companion object {
        var formatter = SimpleDateFormat("dd/MM/yyyy hh:mm:ss")
        val document = arrayListOf("doc", "txt", "docx", "pdf", "html", "ppt", "xlxs", "mhtml")
        val audio = arrayListOf("mp3", "wav")
        val video = arrayListOf("mp4", "avi", "mkv")
        val image = arrayListOf("png", "jpeg", "gif", "jpg")
        var folders = ArrayList<Folder>()
        var pos: Int? = null
        var currentPath: String? = null
    }

    private lateinit var rootView: View
    private lateinit var recyclerView: RecyclerView



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootView = inflater.inflate(R.layout.fragment_list, container, false)
        recyclerView = rootView.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this.context)


        if (!checkFolders())
            Toast.makeText(this.context, "Doesn't Exists", Toast.LENGTH_SHORT).show()
        else
            recyclerView.adapter = FoldersAdapter(folders, this)

        return rootView
    }

    private fun checkFolders(): Boolean {
        if (path.exists()) {
            if (path.isDirectory && path.listFiles() != null && path.listFiles()!!.isNotEmpty()) {
                folders = directoryToFolder(path.listFiles()!!)
                return true
            }
        } else {
            Toast.makeText(this.context, "Empty", Toast.LENGTH_SHORT).show()
        }
        return false
    }

    private fun directoryToFolder(listFiles: Array<File>): ArrayList<Folder> {
        val arrayListFolders = ArrayList<Folder>()
        var typeImage: TypeImage
        listFiles.forEach {
            if (it.isDirectory) typeImage = TypeImage.FOLDER
            else {
                it.toString().apply {
                    val type = this.substring(this.lastIndexOf('.') + 1)
                    typeImage = if (type in document)
                        TypeImage.DOCUMENT
                    else if (type in audio)
                        TypeImage.AUDIO
                    else if (type in video)
                        TypeImage.VIDEO
                    else if (type in image)
                        TypeImage.IMAGE
                    else TypeImage.OTHERS
                }
            }
            arrayListFolders.add(
                Folder(
                    it.name,
                    typeImage.toString(),
                    typeImage.resID,
                    calculateSpace(it),
                    formatToDate(it.lastModified()),
                    it.path
                )
            )
        }
        return arrayListFolders
    }

    private fun formatToDate(lastModified: Long) = formatter.format(lastModified)

    private fun calculateSpace(file: File): Long {
        var size = 0L
        if (file.isDirectory) {
            for (i in file.listFiles()!!) {
                size += calculateSpace(i)
            }
        } else {
            return file.length()
        }
        return size
    }

    override fun onViewHolderClick(position: Int) {
        path = File(folders[position].path)
        currentPath=path.path

        if (checkFolders()) {
            recyclerView.adapter = FoldersAdapter(folders, this)
        } else {

            if (activity!!.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                pos = position
                var intent = Intent(context, DetailActivity::class.java)
                intent.putExtra("name", folders[position].name)
                intent.putExtra("type", folders[position].type)
                intent.putExtra("typeImage", folders[position].typeImage)
                intent.putExtra("size", folders[position].size)
                intent.putExtra("date", folders[position].lastModifiedDate)
                intent.putExtra("path", folders[position].path)

                startActivity(intent)

            } else {
                pos = position
                activity!!.supportFragmentManager.beginTransaction().replace(
                    R.id.detailContainer,
                    SingleFile(folders[position])
                ).setTransition(TRANSIT_FRAGMENT_FADE).addToBackStack(null).commit()
            }
        }

    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        val callback: OnBackPressedCallback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (path.parentFile != null) {
                    path = path.parentFile!!
                    folders.clear()
                    if (checkFolders()) {
                        recyclerView.adapter = FoldersAdapter(folders, this@ListFolder)
                    } else activity!!.finish()
                }
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(this, callback)
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
//        savedInstanceState?.let {
//            curentPath = it.getString("Path")!!
//            path = File(curentPath)
//        }
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onSaveInstanceState(outState: Bundle) {
//        outState.putString("Path", curentPath)
        super.onSaveInstanceState(outState)
    }

    override fun onDetach() {
        super.onDetach()
    }

    override fun onDestroyView() {
        super.onDestroyView()
    }

    override fun onStop() {
        super.onStop()
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
    }
}
