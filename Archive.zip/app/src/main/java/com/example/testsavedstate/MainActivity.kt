package com.example.testsavedstate

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.PersistableBundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.FragmentTransaction.TRANSIT_FRAGMENT_FADE
import androidx.fragment.app.ListFragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.testsavedstate.ListFolder.Companion.currentPath
import com.example.testsavedstate.ListFolder.Companion.pos
import java.io.File
import java.text.SimpleDateFormat

class MainActivity : AppCompatActivity() {
    companion object {
        val permissions = arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        const val PERMISSION_COUNT = 1
        const val REQUEST_PERMISSION = 1234
        var twoPane = false
    }


    lateinit var recyclerView: androidx.recyclerview.widget.RecyclerView
    var path: File = Environment.getExternalStorageDirectory()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        if (savedInstanceState == null) {
//            supportFragmentManager.beginTransaction()
//                .replace(R.id.masterContainer, ListFolder(path))
//                .addToBackStack(null)
//                .commit()
//        }
        if (findViewById<View>(R.id.landscape) != null)
            twoPane = true

        if (supportFragmentManager.findFragmentById(R.id.masterContainer) == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.masterContainer, ListFolder(path))
                .setTransition(TRANSIT_FRAGMENT_FADE).addToBackStack(null)
                .commit()
        }

//        if(twoPane){
//            if (supportFragmentManager.findFragmentById(R.id.detailContainer) == null) {
//                supportFragmentManager.beginTransaction()
//                    .replace(R.id.masterContainer, ListFolder(path))
//                    .setTransition(TRANSIT_FRAGMENT_FADE).addToBackStack(null)
//                    .commit()
//            }
//        }

    }

    override fun onRestoreInstanceState(
        savedInstanceState: Bundle?,
        persistentState: PersistableBundle?
    ) {
        super.onRestoreInstanceState(savedInstanceState, persistentState)
    }

    override fun closeContextMenu() {
        super.closeContextMenu()
    }

    override fun onRestart() {
        super.onRestart()
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && isPermissionDenied()) {
            requestPermissions(permissions, REQUEST_PERMISSION)
            return
        }

//        pos?.let {
//            if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
//                if (findViewById<View>(R.id.landscape) != null) {
//                    supportFragmentManager.beginTransaction().replace(
//                        R.id.detailContainer,
//                        SingleFile(ListFolder.folders[it])
//                    ).setTransition(TRANSIT_FRAGMENT_FADE).addToBackStack(null).commit()
//                }
//                pos=null
//
////                supportFragmentManager.beginTransaction().replace(
////                    R.id.masterContainer,
////                    (supportFragmentManager.findFragmentById(R.id.masterContainer) as ListFolder)
////                ).addToBackStack(null).commit()
//            }
//        }

    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
//            setContentView(R.layout.activity_main)
//            supportFragmentManager.beginTransaction()
//                .replace(R.id.masterContainer, ListFolder(File(currentPath)))
//                .setTransition(TRANSIT_FRAGMENT_FADE).addToBackStack(null)
//                .commit()

            twoPane = false
            pos?.let {
                val intent = Intent(this, DetailActivity::class.java)
                intent.putExtra("name", ListFolder.folders[pos!!].name)
                intent.putExtra("type", ListFolder.folders[pos!!].type)
                intent.putExtra("typeImage", ListFolder.folders[pos!!].typeImage)
                intent.putExtra("size", ListFolder.folders[pos!!].size)
                intent.putExtra("date", ListFolder.folders[pos!!].lastModifiedDate)
                intent.putExtra("path", ListFolder.folders[pos!!].path)

                startActivity(intent)
            }
        } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            twoPane = true
            pos?.let {
                supportFragmentManager.beginTransaction().replace(
                    R.id.detailContainer,
                    SingleFile(ListFolder.folders[it])
                ).setTransition(TRANSIT_FRAGMENT_FADE).addToBackStack(null).commit()
                pos = null
            }
        }
    }

    private fun isPermissionDenied(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            var p = 0
            while (p < PERMISSION_COUNT) {
                if (checkSelfPermission(permissions[p]) != PackageManager.PERMISSION_GRANTED)
                    return true
                p++
            }
        }
        return false
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSION && grantResults.isNotEmpty()) {
            if (isPermissionDenied()) {
                (this.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).clearApplicationUserData()
                recreate()
            } else
                onResume()
        }
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
//        outState.putBoolean("State", true)
        super.onSaveInstanceState(outState, outPersistentState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
//        testBoolean = savedInstanceState.getBoolean("State")
        super.onRestoreInstanceState(savedInstanceState)
    }
}
