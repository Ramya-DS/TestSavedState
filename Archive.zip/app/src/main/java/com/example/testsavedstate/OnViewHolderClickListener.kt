package com.example.testsavedstate

import java.text.FieldPosition

interface OnViewHolderClickListener {
    fun onViewHolderClick(position: Int)
}